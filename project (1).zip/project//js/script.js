<script>
    document.getElementById("LoginForm").addEventListener('submit',function(event) {
    event.preventDefault();
    
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    var errorMessage = document.getElementById("error-massage");
    
    if (username === '' || password === ''){
        errorMessage.textContent = 'Tidak boleh kosong!';
    } else if (username !== 'Ratzy' || password !== '199db') {
        errorMessage.textContent = 'Password atau Username Salah!';
    } else {
        errorMessage.textContent = ''
        alert('Sukses Login!');
    }
    
    });